# Clearify

🌟 Clearify limpia tu navegación eliminando modales molestos, overlays invisibles y anuncios intrusivos. 

## Características:
- Elimina modales tipo "Unlock more content"
- Elimina overlays invisibles que bloquean clics
- Elimina anuncios de Google AdSense
- Fuerza enlaces a abrirse en la misma pestaña
- Restaura el scroll y la navegación fluida

## Cómo instalar (extensión temporal en Safari):
1. Activa el menú Desarrollador en Safari.
2. Haz clic en "Agregar extensión temporal..." y selecciona el archivo `manifest.json`.
3. ¡Disfruta de una navegación limpia!

## Uso ético:
Clearify modifica solamente el contenido local de tu navegador. No recolecta datos ni altera servidores de terceros.

---

Clear your web. Amplify your browsing. 🚀
