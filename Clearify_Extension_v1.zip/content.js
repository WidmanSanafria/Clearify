(() => {
  console.log("🛡️ Clearify activado: anti-modal, anti-click-block y anti-ads");

  window.open = function(url) {
    console.warn("🚫 Redirigido:", url);
    window.location.href = url;
    return null;
  };

  const forzarEnlaces = () => {
    document.querySelectorAll('a[target="_blank"]').forEach(link => {
      link.removeAttribute("target");
      link.onclick = function(e) {
        e.preventDefault();
        window.location.href = this.href;
        console.log("🔗 Forzado:", this.href);
      };
    });
  };

  const eliminarBloqueosYAnuncios = () => {
    const selectores = [
      '.fc-consent-root',
      '.fc-dialog-overlay',
      '.fc-dialog-container',
      '.fc-dialog-content',
      '.fc-dialog',
      '.fc-monetization-dialog-container',
      '.adCard',
      'div[id^="google_ads_iframe"]',
      'iframe[src*="googlesyndication"]',
      'div[class*="adsbygoogle"]',
      'ins.adsbygoogle'
    ];

    selectores.forEach(selector => {
      document.querySelectorAll(selector).forEach(el => {
        el.remove();
        console.log("🧹 Eliminado:", selector);
      });
    });

    document.body.style.overflow = "auto";
    document.body.style.pointerEvents = "auto";
  };

  const activar = () => {
    eliminarBloqueosYAnuncios();
    forzarEnlaces();
  };

  activar();
  setInterval(activar, 1000);
  new MutationObserver(activar).observe(document.body, {
    childList: true,
    subtree: true
  });
})();
